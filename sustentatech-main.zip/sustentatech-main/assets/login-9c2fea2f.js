import e from "./AuthForm-52e5a6a1.js";
import {L as a, bA as r, o as c, d as n} from "./index-69a2ddda.js";
import {b as t} from "./route-block-83d24a4e.js";
const s = {
    __name: "login",
    setup(i) {
        return a(async()=>{
            await r()
        }
        ),
        (_,m)=>{
            const o = e;
            return c(),
            n(o, {
                "redirect-after-auth": !0
            })
        }
    }
};
typeof t == "function" && t(s);
export {s as default};
//# sourceMappingURL=login-9c2fea2f.js.map

