import {o as e, c as o, f as n} from "./index-69a2ddda.js";
const t = {
    viewBox: "0 0 24 24",
    width: "1.2em",
    height: "1.2em"
}
  , r = n("path", {
    fill: "none",
    stroke: "currentColor",
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6m4-3h6v6m-11 5L21 3"
}, null, -1)
  , s = [r];
function c(i, a) {
    return e(),
    o("svg", t, s)
}
const _ = {
    name: "lucide-external-link",
    render: c
};
export {_};
//# sourceMappingURL=external-link-95d7aa13.js.map
