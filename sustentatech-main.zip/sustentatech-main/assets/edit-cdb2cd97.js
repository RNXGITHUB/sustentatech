import {_ as m} from "./SiteEditor-f01fdb6c.js";
import {n as e, u as n, o as s, c as a, b as c, k as _} from "./index-69a2ddda.js";
import {b as i} from "./route-block-83d24a4e.js";
import "./AnimatedLoader-f41ada9f.js";
import "./DomainSettingsButton-376d972c.js";
import "./MagicWrap-b8cea90d.js";
import "./external-link-95d7aa13.js";
import "./sites-4872b2d4.js";
import "./sites-4ce521e7.js";
import "./media-a5bc1cc2.js";
import "./index-ff27ab17.js";
import "./site-machine-85aa4cac.js";
import "./libraries-f7478571.js";
import "./helpers-7cfbe709.js";
import "./trash-x-filled-c1a48d6a.js";
import "./plugins-98ed0274.js";
import "./switch-7a7b90fb.js";
import "./rocket-0acd4cc9.js";
import "./mediaQueries-d2f0f2a6.js";
const u = {
    __name: "edit",
    setup(d) {
        var o;
        const t = e();
        n({
            title: "Editor"
        });
        const r = ((o = t == null ? void 0 : t.params) == null ? void 0 : o.id) || "";
        return (l,f)=>{
            const p = m;
            return s(),
            a("div", null, [c(p, {
                "site-id": _(r)
            }, null, 8, ["site-id"])])
        }
    }
};
typeof i == "function" && i(u);
export {u as default};
//# sourceMappingURL=edit-cdb2cd97.js.map
