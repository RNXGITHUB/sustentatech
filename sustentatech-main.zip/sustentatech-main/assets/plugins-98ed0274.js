const c = s=>{
    var p;
    (p = s == null ? void 0 : s.hook) == null || p.input((t,r)=>r(t == null ? void 0 : t.toLowerCase()))
}
  , i = s=>{
    var p;
    (p = s == null ? void 0 : s.hook) == null || p.input((t,r)=>r(t == null ? void 0 : t.replace(/\s/g, "-")))
}
;
export {c as l, i as s};
//# sourceMappingURL=plugins-98ed0274.js.map
