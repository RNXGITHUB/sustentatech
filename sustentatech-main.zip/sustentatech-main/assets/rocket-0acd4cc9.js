import {o, c as t, f as e} from "./index-69a2ddda.js";
const a = {
    viewBox: "0 0 24 24",
    width: "1.2em",
    height: "1.2em"
}
  , n = e("g", {
    fill: "none",
    stroke: "currentColor",
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2"
}, [e("path", {
    d: "M4 13a8 8 0 0 1 7 7a6 6 0 0 0 3-5a9 9 0 0 0 6-8a3 3 0 0 0-3-3a9 9 0 0 0-8 6a6 6 0 0 0-5 3"
}), e("path", {
    d: "M7 14a6 6 0 0 0-3 6a6 6 0 0 0 6-3m4-8a1 1 0 1 0 2 0a1 1 0 1 0-2 0"
})], -1)
  , r = [n];
function s(c, i) {
    return o(),
    t("svg", a, r)
}
const d = {
    name: "tabler-rocket",
    render: s
};
export {d as _};
//# sourceMappingURL=rocket-0acd4cc9.js.map

